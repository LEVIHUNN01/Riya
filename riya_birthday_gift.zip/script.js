const screens = document.querySelectorAll(".screen");
const hearts = document.getElementById("hearts");
const musicBtn = document.getElementById("musicBtn");
let audioCtx, musicTimer, musicOn = false;

function show(id){
  screens.forEach(s => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

function heartRain(count=28){
  for(let i=0;i<count;i++){
    setTimeout(()=>{
      const h=document.createElement("div");
      h.className="heart";
      h.textContent=["💗","💖","💕","🌸","✨"][Math.floor(Math.random()*5)];
      h.style.left=Math.random()*100+"vw";
      h.style.fontSize=(14+Math.random()*18)+"px";
      h.style.animationDuration=(4+Math.random()*4)+"s";
      hearts.appendChild(h);
      setTimeout(()=>h.remove(),8500);
    },i*120);
  }
}

function confetti(){
  for(let i=0;i<90;i++){
    setTimeout(()=>{
      const c=document.createElement("i");
      c.className="confetti";
      c.style.left=Math.random()*100+"vw";
      c.style.transform=`rotate(${Math.random()*360}deg)`;
      c.style.background=["#ff72ad","#ffd166","#a78bfa","#7dd3fc","#fb7185"][Math.floor(Math.random()*5)];
      c.style.animationDelay=Math.random()*0.5+"s";
      hearts.appendChild(c);
      setTimeout(()=>c.remove(),4500);
    },i*15);
  }
}

// Tiny original melody generated with Web Audio; no external music file is needed.
function startMusic(){
  if(musicOn)return;
  audioCtx = new (window.AudioContext||window.webkitAudioContext)();
  musicOn=true;
  musicBtn.textContent="♫ Music: ON";
  const notes=[523.25,659.25,783.99,659.25,587.33,698.46,880,698.46];
  let i=0;
  function play(){
    if(!musicOn)return;
    const osc=audioCtx.createOscillator(), gain=audioCtx.createGain();
    osc.type="sine"; osc.frequency.value=notes[i%notes.length];
    gain.gain.setValueAtTime(0,audioCtx.currentTime);
    gain.gain.linearRampToValueAtTime(.055,audioCtx.currentTime+.03);
    gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+.42);
    osc.connect(gain);gain.connect(audioCtx.destination);
    osc.start();osc.stop(audioCtx.currentTime+.45);
    i++;musicTimer=setTimeout(play,520);
  }
  play();
}
function stopMusic(){
  musicOn=false;clearTimeout(musicTimer);
  if(audioCtx){audioCtx.close();audioCtx=null}
  musicBtn.textContent="♫ Music: OFF";
}

document.getElementById("openBtn").onclick=()=>{
  show("wish"); heartRain(); confetti(); startMusic();
};
document.getElementById("surpriseBtn").onclick=()=>{
  show("final"); heartRain(45); confetti();
};
document.getElementById("againBtn").onclick=()=>{
  show("welcome"); stopMusic();
};
musicBtn.onclick=()=>musicOn?stopMusic():startMusic();

setInterval(()=>{ if(document.querySelector("#welcome.active")) heartRain(3); },2500);
